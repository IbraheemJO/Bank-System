#pragma once

#include <memory>  // unique_ptr
#include <string>
#include <vector>
#include <map>

namespace Domain::Banking
{


    class MaintainAccountsHandler
    {
    public:
        // Constructors
        MaintainAccountsHandler() = default;        // default ctor
        MaintainAccountsHandler(const MaintainAccountsHandler& original) = default;        // copy ctor
        MaintainAccountsHandler(MaintainAccountsHandler&& original) = default;        // move ctor

        // Operations
        virtual std::vector<std::vector<std::string>> getAccountInfo() = 0;  // retrieves the list of actions (commands)
        virtual std::map<std::string, std::vector<std::string>> selectAccount() = 0;
        virtual std::map<std::string, std::vector<std::string>> getAssignment() = 0;  // retrieves the list of actions (commands)

        static std::unique_ptr<MaintainAccountsHandler> selectCommand(const std::string& command);

        // Destructor
        // Pure virtual destructor helps force the class to be abstract, but must still be implemented
        virtual ~MaintainAccountsHandler() noexcept = 0;

    protected:
        // Copy assignment operators, protected to prevent mix derived-type assignments
        MaintainAccountsHandler& operator=(const MaintainAccountsHandler& rhs) = default;  // copy assignment
        MaintainAccountsHandler& operator=(MaintainAccountsHandler&& rhs) = default;  // move assignment

    };    // class MaintainCoursesHandler





    /*****************************************************************************
    ** Inline implementations
    ******************************************************************************/
    inline MaintainAccountsHandler::~MaintainAccountsHandler() noexcept
    {}


} // namespace Domain::Banking
