#pragma once

#include <memory>
#include <string>
#include <vector>
#include <map>

#include "MaintainBeneficiaryHandler.hpp"

namespace Domain::Banking
{
	
	
  class Assignments : public Domain::Banking::MaintainBeneficiaryHandler
  {
    public:
      // Constructors
      using MaintainBeneficiaryHandler::MaintainBeneficiaryHandler;  // inherit constructors
	  

      // Operations
	  std::map<std::string, std::vector<std::string>> getAssignment() override;

     ~Assignments() noexcept override;
  }; // class Assignments


  /*****************************************************************************
  ** Inline implementations
  ******************************************************************************/
  inline Assignments::~Assignments() noexcept
  {}
  // std::map<std::string, std::vector<std::string>> Assignments;
    
  inline std::map<std::string, std::vector<std::string>> Assignments::getAssignment()
  {
	  std::map<std::string, std::vector<std::string>> Assign;
	  Assign["Assignment 1"] = {{"Question 1: "}, {"Question 2: "}, {"Question 3: "}};
    return Assign;
  }


}  // namespace Domain::Library
