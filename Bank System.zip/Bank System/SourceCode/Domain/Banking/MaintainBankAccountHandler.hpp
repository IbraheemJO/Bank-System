#pragma once

#include <memory>  // unique_ptr
#include <string>
#include <vector>
#include <map>

namespace Domain::Banking
{

  
  class MaintainBankAccountHandler
  {
    public:
      // Constructors
      MaintainBankAccountHandler()                                          = default;        // default ctor
      MaintainBankAccountHandler( const MaintainBankAccountHandler &  original )  = default;        // copy ctor
      MaintainBankAccountHandler(       MaintainBankAccountHandler && original )  = default;        // move ctor

      // Operations
	  virtual std::vector<std::vector<std::string>> getBankAccounts() = 0;  // retrieves the list of actions (commands)
	  virtual std::map<std::string, std::vector<std::string>> selectBeneficiary() = 0;
	  virtual std::map<std::string, std::vector<std::string>> getDetails() = 0;  // retrieves the list of actions (commands)
	  
	  static std::unique_ptr<MaintainBankAccountHandler> selectCommand( const std::string & command );

      // Destructor
      // Pure virtual destructor helps force the class to be abstract, but must still be implemented
      virtual ~MaintainBankAccountHandler() noexcept = 0;

    protected:
      // Copy assignment operators, protected to prevent mix derived-type assignments
      MaintainBankAccountHandler & operator=( const MaintainBankAccountHandler &  rhs ) = default;  // copy assignment
      MaintainBankAccountHandler & operator=(       MaintainBankAccountHandler && rhs ) = default;  // move assignment

  };    // class MaintainCoursesHandler





  /*****************************************************************************
  ** Inline implementations
  ******************************************************************************/
  inline MaintainBankAccountHandler::~MaintainBankAccountHandler() noexcept
  {}


} // namespace Domain::Banking
