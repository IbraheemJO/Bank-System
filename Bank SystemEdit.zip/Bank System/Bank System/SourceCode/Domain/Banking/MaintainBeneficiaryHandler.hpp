#pragma once

#include <memory>  // unique_ptr
#include <string>
#include <vector>

namespace Domain::Banking
{
  // Library Package within the Domain Layer Abstract class
  
  // struct CourseDetails
	// {
    // std::string               courseId;
    // std::string               courseName;
	// std::string               instructor;
	// std::string               schedule;
	// std::string               price;
	// };
  
  class MaintainBeneficiaryHandler
  {
    public:
      // Constructors
      MaintainBeneficiaryHandler()                                          = default;        // default ctor
      MaintainBeneficiaryHandler( const MaintainBeneficiaryHandler &  original )  = default;        // copy ctor
      MaintainBeneficiaryHandler(       MaintainBeneficiaryHandler && original )  = default;        // move ctor

      // Operations
	  virtual std::map<std::string, std::vector<std::string>> getBeneficiary() = 0;  // retrieves the list of actions (commands)
	  
	  // static std::unique_ptr<MaintainBeneficiaryHandler> createCommand( const std::string & command );

      // Destructor
      // Pure virtual destructor helps force the class to be abstract, but must still be implemented
      virtual ~MaintainBeneficiaryHandler() noexcept = 0;

    protected:
      // Copy assignment operators, protected to prevent mix derived-type Beneficiaries
      MaintainBeneficiaryHandler & operator=( const MaintainBeneficiaryHandler &  rhs ) = default;  // copy assignment
      MaintainBeneficiaryHandler & operator=(       MaintainBeneficiaryHandler && rhs ) = default;  // move assignment

  };    // class MaintainBeneficiaryHandler





  /*****************************************************************************
  ** Inline implementations
  ******************************************************************************/
  inline MaintainBeneficiaryHandler::~MaintainBeneficiaryHandler() noexcept
  {}


} // namespace Domain::Banking
