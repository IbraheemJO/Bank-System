#pragma once

#include <memory>
#include <string>
#include <vector>

#include "Session.hpp"


namespace Domain::Banking
{
  class CustomerSession : public Domain::Banking::SessionHandler
  {
    public:
      using SessionHandler::SessionHandler;  // inherit constructors

      // Operations
      std::vector<std::string> getCommands() override;  // retrieves the list of actions (commands)
	  
	  //std::vector<std::string> getCourses() override;

      // Destructor
      // Pure virtual destructor helps force the class to be abstract, but must still be implemented
     ~CustomerSession() noexcept override;
  }; // class StudentSession





  /*****************************************************************************
  ** Inline implementations
  ******************************************************************************/
  inline CustomerSession::~CustomerSession() noexcept
  {}


  inline std::vector<std::string> CustomerSession::getCommands()
  {
    return { "Edit Profile", "Transfer Money", "Submit Truoble", "View Report" };
  }
  
} // namespace Domain::Banking
