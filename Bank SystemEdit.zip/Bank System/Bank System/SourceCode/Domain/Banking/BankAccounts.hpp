#pragma once

#include <memory>
#include <string>
#include <vector>

#include "MaintainBankAccountHandler.hpp"


namespace Domain::Banking
{
	
	
  class BankAccounts : public Domain::Banking::MaintainBankAccountHandler
  {
    public:
      // Constructors
      using MaintainBankAccountHandler::MaintainBankAccountHandler;  // inherit constructors
	  

      // Operations
	  std::vector<std::vector<std::string>> getBankAccounts() override;
	  std::map<std::string, std::vector<std::string>> selectBeneficiary() override;
	  std::map<std::string, std::vector<std::string>> getDetails() override;

     ~BankAccounts() noexcept override;
  }; // class BankAccounts


  /*****************************************************************************
  ** Inline implementations
  ******************************************************************************/
  inline BankAccounts::~BankAccounts() noexcept
  {}
  
  
  
  inline std::vector<std::vector<std::string>> BankAccounts::getBankAccounts()
  {
    
    return { {"100001", "Vaishali K", "6572754219", "vkhairnar@gmail.com", "$2400", "Savings Account"}, {"100002", "Ashu K", "7892342617", "ak@gmail.com", "$10500", "Checking Account"} /*, {"CPSC 103", "software measuement", "Prashant", "M-W 5:30-7:00", "$2400", "Assignment 4"}, {"CPSC 104", "software verification and validation", "Prashant", "Tu-Th 5:00-6:30", "$2400", "Assignment 5"} */};
  }
  
  inline std::map<std::string, std::vector<std::string>> BankAccounts::selectBeneficiary()
  {
	  std::map<std::string, std::vector<std::string>> AssignBeneficiary;
	  AssignBeneficiary["100001"] = {"100001", "100002"};
	  AssignBeneficiary["100002"] = {"100001", "100004"};

	  return AssignBeneficiary;
  }
  
  inline std::map<std::string, std::vector<std::string>> BankAccounts::getDetails()
  {
	  std::map<std::string, std::vector<std::string>> Assign;
	  Assign["100001"] = {{"Name:"}, {"Phone No: "}, {"Email:"}};
	  Assign["100002"] = {{"Name: Ashu K "}, {"Phone No:7892342617 "}, {"Email: ak@gmail.com "}};
	
    return Assign;
  }


}  // namespace Domain::Banking
